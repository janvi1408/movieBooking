package com.cg.categories.exception;

public class InvalidCategoryException extends Exception{
public InvalidCategoryException(String message) {
	super(message);
}
}
