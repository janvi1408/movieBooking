package com.cg.categories.exception;

public class InvalidIdException extends Exception{
public InvalidIdException(String message) {
	super(message);
}
}
