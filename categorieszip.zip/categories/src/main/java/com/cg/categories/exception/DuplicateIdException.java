package com.cg.categories.exception;

public class DuplicateIdException extends Exception{
public DuplicateIdException(String message) {
	super(message);
}
}
