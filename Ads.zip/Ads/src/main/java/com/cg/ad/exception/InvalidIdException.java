package com.cg.ad.exception;

public class InvalidIdException extends Exception{
public InvalidIdException(String message) {
	super(message);
}
}
